/* ============================================================
   SANA TOURS & TRAVELS — MAIN SCRIPT
   ============================================================ */

// ── Logo base64 (embedded) ────────────────────────────────
const LOGO_B64 = '/9j/4AAQSkZJRgABAQAAAQABAAD/7QCEUGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAGgcAigAYkZCTUQwYTAwMGFiNTAxMDAwMGU2MDIwMDAwMDEwNDAwMDA2MTA0MDAwMGQ4MDQwMDAwYTUwNjAwMDBmOTA4MDAwMDUyMDkwMDAwYzAwOTAwMDAxNDBhMDAwMDM0MGQwMDAwAP/bAIQABQYGCwgLCwsLCw0LCwsNDg4NDQ4ODw0ODg4NDxAQEBEREBAQEA8TEhMPEBETFBQTERMWFhYTFhUVFhkWGRYWEgEFBQUKBwoICQkICwgKCAsKCgkJCgoMCQoJCgkMDQsKCwsKCw0MCwsICwsMDAwNDQwMDQoLCg0MDQ0MExQTExOc/8IAEQgAlgCWAwEiAAIRAQMRAf/EAIAAAQACAwEBAQAAAAAAAAAAAAABBwMFBgQCCBAAAQICBQcIBwkBAAAAAAAAAQACAxEEEiEzoRMVMUFRkdEFECAiUmFxwRQjMmBygbEwQEJQgqLh8PGSEQABBAAEBQQCAwEAAAAAAAABABEhMRBBUWFxgZHh8aGxwfAg0TBAUGD/2gAMAwEAAgADAAAAAblRIgJQJQJIJQJIJQJQJpq5KbLkJIAAAAAlAJIApu5KbLkAJIAAAAAAApu5KbLlQNHjo72evzXK5Cuvmb0U7rPqL1fnzpEW+/PnXFqqO1cv0KqHRw/Q20p24vPmU3clN/GS5Afm60au2Ow8Xa6vZ13hy+7087PowbPdcpgG/wBJjn56vRYsUT1fOYcJ3Fz0xc/k9Sm7kpvBmuQk5rF1L6+eWdN9I5dudf8AUeZsJhrnqyy8DfeiJ5l0uSGl3RH0pu5KbiblQHk9ZGqnaJaHJupRq8G6GnjdQarLsJTpdnmARKm7kpsuQACYAEwAExMAEwCm7kpsuQkgBIgBMEwBMAACm7kpsuRTYuRTYuRTYuRTYuRTYuRTYuRTYuRTYuRTYuSmw//aAAgBAQABBQL30dT4LTnGAs4wFnGAs4wFnGAs4wFnKAs4wFnGAs5QFnGAoVLhxT0KXfUSimM6JySGNjQjDUOj+pi1JKlUQQ2BRKG10MBuSXogyGWcuRXF0boUy95Jc1rIQbHictSykARYYpxDm0VpaqE4Rg5paXvfAdSTDfCo0HKOotKBjUmAYL+Q77oUu+olMySzxZSKQYpFVdVdVOkiGysqmpPqrqzslyHfdB/JkBxzTR1mqjrNNHWaqOs00dZpo6zTR1mqjrNNHWaqOs00dZpo6zVR1AoUKCelWCmok3KpEVWImh82tiqUSUPqiarD7CLDrgUeRZR6p9DEnUUOOQtdRQ4+jI0ZOoocsjaaKExlQe+v/2gAIAQMAAT8B+/5YzlJOiObqCyx7kIx2CxCMTqCy57kYxGpQ3VhPnY6TlFiAjV8rFOySDpLQiUTNQPZ56g2Dcqg2Dcqo7Kqjs4KqOzgqg2BVBsG5AS6ElVCkpKSl+Q//2gAIAQIAAT8B+/5ASnNNhNdoJWQG04I0dolabUYDRrNq9HG0oQAdBURlUy53trN3KBBLTpcRqrGfl/KlbPyRbPy7kbUBZK1ASKpHtc9c9o71Xd2jvVY9o7yqx7R3lVj2sSq57R3qu7tHeiZ9CarKampqf5D/AP/aAAgBAQAGPwL30IMRswr1qvWq9ar1qvWq9ar1qvWq9ar1qvWq9ar1qkx4cdPRi/G76oCU8JDafJTm3cf90qREpG3aDwWVq5TrSImeqBrMrU0sEjbWE58zHNM9LX9zx/cOYPhaQ0OeycyAdYRdLrBwE5nWCfLmL5+sbJzhsY7RxWlOmZ+rP1HRi/G76qKdhH/IbYrcq8TnbWDQv0NnvswQiQibSQQLdHdrChuLQyKZ1wNmokakY1WYh6O9x4aVEgVaoeJgzJk4aNKkRIqC8WEQ2+dirw7K8RtZnZNV2BWjqttd4DV4nQrYd71X2k2Hu7kWn5HaE74D9R0Yvxu+q/p3r8IO2ZdgsfEpuO1fL5Vk79qGKEjbrR2zQ2a0ds7PBDZVxlxXfPBO+A/UdEkstJmbTxV3i7irvF3FXeLuKu8XcVd4u4q7xdxV3i7irvF3FXeLuKu8XcVd4u4q7xdxV3i7ipsbIylpP2IquAtQ9YF7YOHl4q140S+Z0/wpVhZw4r2wT5ITNuvm0/YVZympzt62rtfxYpz24malM6OPFTnqlKViYa3sD/VOf4q2jw8gnWm2f7pcEbdIA0bFbsA8JJxn7Q3IW6AG6NQM1L32/9oACAEBAQE/If8AtAxxSCCaIsLzvZed7LzvZed7LzvZed7Lyq872Xney8r2Xney872XnOyNBIHAW2v4/Z60HEkmWapvkzT1PBspyzMCHkzVEC8MAchT0SEg5qQBk8QAEdhpPxYBEZwaZGQQzG2I1lAElhJMAakppbl5FyOFgc2aKafbxKeXmmeDGMkQXCvKDwGfmp8BaDiaC8uschVM4qoReMWZ+P8AX6kRMOCdh+yH3QglfHMMBk3JA419S/q9ie/NSiGfOPbQVlR3pw4oO8oKYqmckN2mRyICkpFrbY5H9UWHBLEbp7ETkQcxfIR7NI0lxuI4+gHmIiLeg7Og4o61DGWbQ0OAVKwJ0sgjle/5S/s9aOYlmgFmNoGY00TQ0BhuBugLunlLO4m6HPKAMkVsSXh4PHpouR3uZsg616oRyl9VT2UDbbq+9E89iY+IpufB6Aia3Zi+1spsVEJct+6RYAsJJks9mb12TZDMtf62j0nq+35S3OpRLyZP8xTRTRRTRRRRTQrfzhciDmTp+bkOOqZTrJAcZtgY4UU6SLoyyMaMqjsKDLc+r0ZCETaAMmHND19OgZCYA5Yu1qfe+R1QAVw+VAaoOTyUE61yJsm+T0gLs4fR0dB1Cd/zc3ADJQdjipZD2BmyFNls45zViS3Ep/QoyEgC/MmSNU+XowXffOJgLPRgAIEuGI7mDy3WaB1DEwD7Bjm6bKYReIs6UQSArsoPIYu9l31ARskySyMBmjKXOXBQGYWKFBDHiSeaIAZEhQ9QABQgjLa7lz6n/oj/U//2gAMAwEBAgEDAQAAECHDDBDBDDCKPPPPPJKPKPOPPPPPPPKDCHzAybld6PDpGME841KOPq5R5Ha/aCPfO5dWLPKPPLPHPFPHKOPMNNFNPOIMMMMEMMIMIP/aAAgBAwEBPxD++6wBls1YeoiGWo7TSLBO4tOTQZS6IGiXFMjhIcfXXNBxAYnUqPACbbLk/wCl9ho6hQPUaugZNxBemTheI0zTLgbXuHHwxeGI6M8gtn0LZ9C8MF4YgQAbhGJDpq2E1NTUwf4P/9oACAECAQE/EP77YEYh8sOQOWzG+rRADpE2vuIbmgd8jgnZyCxy+F0piygafgtBkUCHQhry6Ygy3gMfOF5ghhxxv0ecLzBEkSTxnEFsLk9P/wAM/9oACAEBAQE/ELTqsHdPhadO2Fp8LTp2wtUmVrZUmfAwmVrZGEytUmVrZGEF7I4DAoL2RWSGBQXsjgEZToRhaGBlOhC3RlPgZwELdGVSbNWnZUrwpMrT5Kkyd1SZWnVITgYwEqkyvAwmQnG8DCZWj64E4NcctiRYK89Q9+J56nnqHv1PPUHdv6XnqHv1PLU89Q9+oaZeJDcSkywSBYCHIXsiqxIHHV1nb2JngWmFGpzXNMyuH00qOYMP2FxL0BECpuAoljWGS7jkoSASABcAAbkqbtBLIoAwBLLyRIfmzoU72T9BiEOJB3GOSDBTLZOusoFo6iuENPsNIfJBAIAJuWqTqleKMk/OPfJ71fDJIGiIb6CG9QkV2hluGfcECjc+fapfwIYghQsbhBB8mrJ2SOhk6wERI+WxF5KcHx7h7jdwiMPqAoZhZneAs26fWukk6LUn3Vh6jTY4YEGVoxiQBhLxEemWSmbbNy2uwEbLFEJSaR+yGQU6Co8l61bkII5CbNouS6O/E36Wf5AcpfH8jL1LSQbo8vwP2EDBmB6lI8ABTJMH5R9sxu1eZDrKJfoMnP2ck33H+BxbFsCBhDCFdwLtxgADnQfzGym2imm2mmmi2u5ukMyQMNYZLJCLVp1SOqBLDF2YAS42dMFwOXYOHLX0QuevUgmySa57wq8n9IdVM+Zj2EDmIKRw5GkCRECzZeoTwa3zjGcgZDHDoBuWNwk0QstFicwHQyMiSAwWAOG2tQ3C4cZg1ukGIzVLdGVSZWnqMAJvty2zQwTy6jE8ReIQzAhDEg8+6EHMYowGsgeSk4zKFrjIEIWSw1IOgQJ7niG4QbNPgSdE6eQsAz/aBF+6+dnG5Y2aUoQmiODWCL50CHQwiP33Jho6DQNF6BzBvZ2I7YV0BJnvdT6o4pB82JJsWQIFCFa2VIL2RQQRwC9kcBgUF7I4BGU6GFoKkZTqlujKfAynVLdGVSZWqhUrTqk2atPkqTK1WFp1SE4UrQlUmZXgYTITgzITgYTK0cBgUMDgPVeyKGBwC9sAjAp8DKtBboynQhWiUFujKdCF/9k=';

// ── Logo SVG fallback ──────────────────────────────────────
function getLogo(cls = '', extraStyle = '') {
  return `<img src="data:image/jpeg;base64,${LOGO_B64}" class="${cls}" alt="Sana Tours & Travels Logo" style="${extraStyle}" onerror="this.style.display='none'">`;
}

// ── DOM Ready ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initLoader();
  initCursor();
  initNavbar();
  initReveal();
  initAccordions();
  initTabs();
  renderPage();
  initWhatsApp();
  initToast();
  if (typeof initHomePopups === 'function') initHomePopups();
});

// ── Page Loader ────────────────────────────────────────────
function initLoader() {
  const loader = document.getElementById('page-loader');
  if (!loader) return;
  setTimeout(() => {
    loader.classList.add('hidden');
    document.body.style.overflow = '';
    setTimeout(() => loader.remove(), 800);
  }, 2200);
  document.body.style.overflow = 'hidden';
}

// ── Custom Cursor ──────────────────────────────────────────
function initCursor() {
  const cursor = document.getElementById('cursor');
  const trail = document.getElementById('cursor-trail');
  if (!cursor || !trail) return;
  let mx = 0, my = 0, tx = 0, ty = 0;
  document.addEventListener('mousemove', e => {
    mx = e.clientX; my = e.clientY;
    cursor.style.left = mx + 'px';
    cursor.style.top = my + 'px';
  });
  (function anim() {
    tx += (mx - tx) * 0.15;
    ty += (my - ty) * 0.15;
    trail.style.left = tx + 'px';
    trail.style.top = ty + 'px';
    requestAnimationFrame(anim);
  })();
  document.querySelectorAll('a, button, .card, .gallery-item').forEach(el => {
    el.addEventListener('mouseenter', () => {
      cursor.style.transform = 'translate(-50%,-50%) scale(1.8)';
      trail.style.transform = 'translate(-50%,-50%) scale(0.5)';
    });
    el.addEventListener('mouseleave', () => {
      cursor.style.transform = 'translate(-50%,-50%) scale(1)';
      trail.style.transform = 'translate(-50%,-50%) scale(1)';
    });
  });
}

// ── Navbar ─────────────────────────────────────────────────
function initNavbar() {
  const nav = document.getElementById('navbar');
  const ham = document.getElementById('hamburger');
  const mobileNav = document.getElementById('mobile-nav');
  if (!nav) return;

  const setNav = () => {
    if (window.scrollY > 60) {
      nav.classList.add('scrolled');
      nav.classList.remove('transparent');
    } else {
      nav.classList.remove('scrolled');
      nav.classList.add('transparent');
    }
  };
  setNav();
  window.addEventListener('scroll', setNav);

  if (ham && mobileNav) {
    ham.addEventListener('click', () => {
      ham.classList.toggle('open');
      mobileNav.classList.toggle('open');
      document.body.style.overflow = mobileNav.classList.contains('open') ? 'hidden' : '';
    });
    mobileNav.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        ham.classList.remove('open');
        mobileNav.classList.remove('open');
        document.body.style.overflow = '';
      });
    });
  }

  // highlight active page
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    if (a.getAttribute('href') === path) a.classList.add('active');
  });
}

// ── Scroll Reveal ──────────────────────────────────────────
function initReveal() {
  const els = document.querySelectorAll('.reveal, .reveal-left, .reveal-right');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });
  els.forEach(el => io.observe(el));
}

// ── Accordions ────────────────────────────────────────────
function initAccordions() {
  document.querySelectorAll('.accordion-header').forEach(header => {
    header.addEventListener('click', () => {
      const item = header.parentElement;
      const wasOpen = item.classList.contains('open');
      document.querySelectorAll('.accordion-item').forEach(i => i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });
}

// ── Tabs ───────────────────────────────────────────────────
function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      const parent = btn.closest('[data-tabs]') || document;
      parent.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      parent.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      const panel = document.getElementById(target);
      if (panel) panel.classList.add('active');
    });
  });
}

// ── Popup Engine ───────────────────────────────────────────
function openPopup(id) {
  const overlay = document.getElementById(id);
  if (!overlay) return;
  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closePopup(id) {
  const overlay = document.getElementById(id);
  if (!overlay) return;
  overlay.classList.remove('open');
  document.body.style.overflow = '';
}
// close on overlay click
document.addEventListener('click', e => {
  if (e.target.classList.contains('popup-overlay')) {
    e.target.classList.remove('open');
    document.body.style.overflow = '';
  }
});
// close on ESC
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.popup-overlay.open').forEach(p => {
      p.classList.remove('open');
      document.body.style.overflow = '';
    });
  }
});

// ── WhatsApp ───────────────────────────────────────────────
function initWhatsApp() {
  const btn = document.getElementById('whatsapp-float');
  if (!btn) return;
  btn.addEventListener('click', () => {
    window.open('https://wa.me/919876543210?text=Assalamu%20Alaikum%2C%20I%20am%20interested%20in%20Hajj%2FUmrah%20packages', '_blank');
  });
}

// ── Toast ──────────────────────────────────────────────────
function initToast() { /* ready */ }
function showToast(msg, icon = '✅') {
  let toast = document.getElementById('global-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'global-toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.innerHTML = `<span>${icon}</span><span>${msg}</span>`;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3500);
}

// ── Form Submissions ───────────────────────────────────────
function handleFormSubmit(e) {
  e.preventDefault();
  const btn = e.target.querySelector('[type=submit]');
  const original = btn.textContent;
  btn.textContent = 'Sending...';
  btn.disabled = true;
  setTimeout(() => {
    btn.textContent = original;
    btn.disabled = false;
    e.target.reset();
    closePopup('enquiry-popup');
    closePopup('booking-popup');
    showToast('JazakAllah Khair! We will contact you soon. 🌙');
  }, 1500);
}
document.addEventListener('submit', handleFormSubmit);

// ── Counter Animation ──────────────────────────────────────
function animateCounter(el, target) {
  let count = 0;
  const step = Math.ceil(target / 60);
  const timer = setInterval(() => {
    count += step;
    if (count >= target) { count = target; clearInterval(timer); }
    el.textContent = count.toLocaleString() + (el.dataset.suffix || '');
  }, 25);
}
const counterObserver = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      const num = parseInt(e.target.dataset.count);
      animateCounter(e.target, num);
      counterObserver.unobserve(e.target);
    }
  });
});
document.querySelectorAll('[data-count]').forEach(el => counterObserver.observe(el));

// ── SHARED COMPONENTS ──────────────────────────────────────
function renderNavbar() {
  const path = window.location.pathname.split('/').pop() || 'index.html';
  const links = [
    { href: 'index.html',    label: 'Home' },
    { href: 'packages.html', label: 'Packages' },
    { href: 'about.html',    label: 'About Us' },
    { href: 'gallery.html',  label: 'Gallery' },
    { href: 'faq.html',      label: 'FAQ' },
    { href: 'contact.html',  label: 'Contact', cls: 'nav-cta' },
  ];
  return `
  <nav class="navbar transparent" id="navbar">
    <a href="index.html" class="nav-logo">
      ${getLogo('', 'height:52px;width:auto;')}
      <div class="nav-logo-text">
        <span>Sana Tour</span>
        <span>Tours &amp; Travels</span>
      </div>
    </a>
    <ul class="nav-links">
      ${links.map(l => `<li><a href="${l.href}" class="${l.cls || ''}${path===l.href?' active':''}">${l.label}</a></li>`).join('')}
    </ul>
    <div class="hamburger" id="hamburger">
      <span></span><span></span><span></span>
    </div>
  </nav>
  <div class="mobile-nav" id="mobile-nav">
    ${links.map(l => `<a href="${l.href}">${l.label}</a>`).join('')}
  </div>`;
}

function renderFooter() {
  return `
  <footer>
    <div class="container">
      <div class="footer-grid">
        <div>
          ${getLogo('footer-logo-img', 'height:65px;margin-bottom:20px;display:block;')}
          <p class="footer-desc">Authorized Agent of Atlas Tours &amp; Travels Pvt Ltd. We are dedicated to making your spiritual journey to the holy lands a blessed and unforgettable experience.</p>
          <p style="color:var(--gold);font-family:var(--font-arabic);font-size:18px;margin-bottom:20px;direction:rtl;">لَبَّيْكَ اللَّهُمَّ لَبَّيْك</p>
          <div class="footer-social">
            <a class="social-btn" href="#" aria-label="Facebook">📘</a>
            <a class="social-btn" href="#" aria-label="Instagram">📸</a>
            <a class="social-btn" href="#" aria-label="YouTube">▶️</a>
            <a class="social-btn" href="#" aria-label="WhatsApp">💬</a>
          </div>
        </div>
        <div>
          <div class="footer-heading">Quick Links</div>
          <ul class="footer-links">
            <li><a href="index.html">Home</a></li>
            <li><a href="packages.html">Hajj Packages</a></li>
            <li><a href="packages.html">Umrah Packages</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="gallery.html">Gallery</a></li>
            <li><a href="faq.html">FAQ</a></li>
            <li><a href="contact.html">Contact</a></li>
          </ul>
        </div>
        <div>
          <div class="footer-heading">Our Services</div>
          <ul class="footer-links">
            <li><a href="#">Visa Assistance</a></li>
            <li><a href="#">Hotel Booking</a></li>
            <li><a href="#">Flight Tickets</a></li>
            <li><a href="#">Ziyarat Tours</a></li>
            <li><a href="#">Group Packages</a></li>
            <li><a href="#">Private Packages</a></li>
            <li><a href="#">Documentation Help</a></li>
          </ul>
        </div>
        <div>
          <div class="footer-heading">Contact Us</div>
          <div class="footer-contact-item">
            <div class="footer-contact-icon">📍</div>
            <div>123 Masjid Road, Muslim Colony, Mumbai – 400001, India</div>
          </div>
          <div class="footer-contact-item">
            <div class="footer-contact-icon">📞</div>
            <div>+91 98765 43210<br>+91 87654 32109</div>
          </div>
          <div class="footer-contact-item">
            <div class="footer-contact-icon">✉️</div>
            <div>info@sanatours.com<br>hajj@sanatours.com</div>
          </div>
          <div class="footer-contact-item">
            <div class="footer-contact-icon">🕌</div>
            <div>Mon–Sat: 9AM–7PM<br>Fri: Closed 12–2PM</div>
          </div>
        </div>
      </div>
      <div class="footer-bottom">
        <div>© 2024 <span>Sana Tour &amp; Travels</span> | Authorized Agent of Atlas Tours &amp; Travels Pvt Ltd</div>
        <div>Made with <span>❤️</span> for the Ummah | All Rights Reserved</div>
      </div>
    </div>
  </footer>`;
}

function renderLoader() {
  return `
  <div class="page-loader" id="page-loader">
    <div class="loader-logo">${getLogo('', 'width:120px;')}</div>
    <div style="font-family:var(--font-arabic);color:var(--gold-light);font-size:22px;direction:rtl;">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>
    <div class="loader-bar"><div class="loader-fill"></div></div>
    <div class="loader-text">Loading Your Journey...</div>
  </div>`;
}

function renderGlobalUI() {
  return `
  ${renderLoader()}
  <div class="cursor" id="cursor"></div>
  <div class="cursor-trail" id="cursor-trail"></div>
  <div id="whatsapp-float" class="whatsapp-float" title="Chat on WhatsApp">💬</div>

  <!-- Enquiry Popup -->
  <div class="popup-overlay" id="enquiry-popup">
    <div class="popup-box">
      <div class="popup-header">
        <button class="popup-close" onclick="closePopup('enquiry-popup')">✕</button>
        <div style="font-size:36px;margin-bottom:12px;">🕌</div>
        <h3>Free Consultation</h3>
        <p>Let us plan your blessed journey</p>
      </div>
      <div class="popup-body">
        <form>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Full Name</label>
              <input class="form-control" type="text" placeholder="Your name" required>
            </div>
            <div class="form-group">
              <label class="form-label">Phone</label>
              <input class="form-control" type="tel" placeholder="+91 XXXXX" required>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Email Address</label>
            <input class="form-control" type="email" placeholder="email@example.com">
          </div>
          <div class="form-group">
            <label class="form-label">Interested In</label>
            <select class="form-control">
              <option>Hajj Package 2025</option>
              <option>Umrah – Economy</option>
              <option>Umrah – Premium</option>
              <option>Umrah – VIP Luxury</option>
              <option>Group Package</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">No. of Pilgrims</label>
            <select class="form-control">
              <option>1 Person</option>
              <option>2 Persons (Couple)</option>
              <option>Family (3–5)</option>
              <option>Group (6+)</option>
            </select>
          </div>
          <button type="submit" class="btn btn-gold" style="width:100%;justify-content:center;">
            🌙 Submit Enquiry
          </button>
        </form>
      </div>
    </div>
  </div>

  <!-- Booking Popup -->
  <div class="popup-overlay" id="booking-popup">
    <div class="popup-box">
      <div class="popup-header">
        <button class="popup-close" onclick="closePopup('booking-popup')">✕</button>
        <div style="font-size:36px;margin-bottom:12px;">📿</div>
        <h3>Book Your Package</h3>
        <p>Secure your spot for this holy journey</p>
      </div>
      <div class="popup-body">
        <form>
          <div class="form-group">
            <label class="form-label">Full Name (as per passport)</label>
            <input class="form-control" type="text" required placeholder="Full legal name">
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Phone</label>
              <input class="form-control" type="tel" placeholder="+91 XXXXX" required>
            </div>
            <div class="form-group">
              <label class="form-label">Passport No.</label>
              <input class="form-control" type="text" placeholder="AB1234567">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Package Type</label>
            <select class="form-control">
              <option>Hajj 2025 – Standard</option>
              <option>Hajj 2025 – Premium</option>
              <option>Umrah – Economy</option>
              <option>Umrah – Premium</option>
              <option>Umrah – VIP</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Message / Special Requirements</label>
            <textarea class="form-control" rows="3" placeholder="Any special needs, wheelchair, etc."></textarea>
          </div>
          <button type="submit" class="btn btn-gold" style="width:100%;justify-content:center;">
            ✈️ Confirm Booking Request
          </button>
          <p style="text-align:center;font-size:12px;color:#999;margin-top:12px;">Our team will call you within 24 hours to confirm</p>
        </form>
      </div>
    </div>
  </div>`;
}

// ── PAGES ──────────────────────────────────────────────────
function renderPage() {
  const path = window.location.pathname.split('/').pop() || 'index.html';
  const app = document.getElementById('app');
  if (!app) return;

  if (path === 'index.html' || path === '') renderHome(app);
  else if (path === 'packages.html') renderPackages(app);
  else if (path === 'about.html') renderAbout(app);
  else if (path === 'gallery.html') renderGallery(app);
  else if (path === 'faq.html') renderFaq(app);
  else if (path === 'contact.html') renderContact(app);

  // After render, reinit
  setTimeout(() => {
    initCursor();
    initReveal();
    initAccordions();
    initTabs();
    initNavbar();
    initWhatsApp();
    // counters
    document.querySelectorAll('[data-count]').forEach(el => counterObserver.observe(el));
  }, 50);
}

// ──────────────────────────────────────────────────────────
// HOME PAGE
// ──────────────────────────────────────────────────────────
function renderHome(app) {
  app.innerHTML = `
  ${renderNavbar()}
  ${renderGlobalUI()}

  <!-- HERO -->
  <section class="hero">
    <div class="hero-bg"></div>
    <div class="hero-pattern"></div>
    <div class="container hero-content">
      <div class="hero-tagline">Authorized Hajj &amp; Umrah Services</div>
      <div class="hero-arabic">لَبَّيْكَ اللَّهُمَّ لَبَّيْك</div>
      <h1 class="hero-h1">Your Sacred<br>Journey to<br><em>Al-Haramain</em></h1>
      <p class="hero-desc">Experience the ultimate spiritual journey with Sana Tour &amp; Travels — trusted by thousands of pilgrims, guided by faith, and committed to your comfort every step of the way.</p>
      <div class="hero-btns">
        <button class="btn btn-gold" onclick="openPopup('booking-popup')">✈️ Book Your Hajj / Umrah</button>
        <a href="packages.html" class="btn btn-outline">🌙 View Packages</a>
      </div>
      <div class="hero-stats">
        <div>
          <div class="hero-stat-num" data-count="15000" data-suffix="+">0</div>
          <div class="hero-stat-label">Happy Pilgrims</div>
        </div>
        <div>
          <div class="hero-stat-num" data-count="20" data-suffix="+ Yrs">0</div>
          <div class="hero-stat-label">Experience</div>
        </div>
        <div>
          <div class="hero-stat-num" data-count="100" data-suffix="%">0</div>
          <div class="hero-stat-label">Visa Success</div>
        </div>
        <div>
          <div class="hero-stat-num" data-count="50" data-suffix="+">0</div>
          <div class="hero-stat-label">Destinations</div>
        </div>
      </div>
    </div>
    <div class="hero-scroll">Scroll</div>
  </section>

  <!-- FEATURES STRIP -->
  <section class="features-strip">
    <div class="container">
      <div class="grid-4">
        <div class="feat-item">
          <div class="feat-icon">🛂</div>
          <div class="feat-text"><h4>100% Visa Success</h4><p>Expert documentation support</p></div>
        </div>
        <div class="feat-item">
          <div class="feat-icon">🏨</div>
          <div class="feat-text"><h4>5-Star Hotels</h4><p>Steps from Haram Al-Sharif</p></div>
        </div>
        <div class="feat-item">
          <div class="feat-icon">👨‍💼</div>
          <div class="feat-text"><h4>Expert Guides</h4><p>Scholars accompanying group</p></div>
        </div>
        <div class="feat-item">
          <div class="feat-icon">💳</div>
          <div class="feat-text"><h4>Easy EMI Plans</h4><p>0% interest installments</p></div>
        </div>
      </div>
    </div>
  </section>

  <!-- PACKAGES PREVIEW -->
  <section class="section-pad" style="background:var(--cream);">
    <div class="container">
      <div class="text-center reveal">
        <div class="section-subtitle">Our Offerings</div>
        <h2 class="section-title">Sacred Packages for Every Pilgrim</h2>
        <p class="section-desc" style="margin-top:16px;">From economy to luxury, we have thoughtfully designed packages to serve pilgrims of all budgets — because this journey is for everyone.</p>
      </div>
      <div style="margin-top:16px;text-align:center;">
        <div class="tab-nav" style="justify-content:center;" data-tabs>
          <button class="tab-btn active" data-tab="tab-umrah">🌙 Umrah</button>
          <button class="tab-btn" data-tab="tab-hajj">🕋 Hajj</button>
          <button class="tab-btn" data-tab="tab-ziyarat">🗺 Ziyarat</button>
        </div>
      </div>

      <div id="tab-umrah" class="tab-panel active">
        <div class="grid-3" style="margin-top:32px;">
          ${packageCard('Economy Umrah','15 Days — All Inclusive','₹85,000','Economy','🌙','Comfortable 3-star accommodation near Haram. Ideal for budget-conscious pilgrims seeking a fulfilling spiritual experience.','economy')}
          ${packageCard('Premium Umrah','12 Days — Premium Stay','₹1,35,000','Most Popular','⭐','Luxury 4-star hotels within walking distance of Masjid Al-Haram & Masjid An-Nabawi. Premium comfort, guided ziyarat.','premium')}
          ${packageCard('VIP Luxury Umrah','10 Days — VIP Experience','₹2,10,000','VIP','👑','5-star Hilton / Marriott stay. Private transport, personal guide, exclusive ziyarat, VIP access, airport transfers.','vip')}
        </div>
      </div>
      <div id="tab-hajj" class="tab-panel">
        <div class="grid-3" style="margin-top:32px;">
          ${packageCard('Hajj Standard','25 Days Guided','₹3,50,000','Hajj 2025','🕋','Complete Hajj package with accommodation in Makkah, Madinah & Mina. All rituals fully guided by experienced Aalim.','hajj-std')}
          ${packageCard('Hajj Premium','25 Days Premium','₹5,20,000','Most Sought','✨','Premium hotels, AC tents in Mina, exclusive group, special scholar-led programs, pre-Hajj training sessions.','hajj-prem')}
          ${packageCard('Hajj VIP','25 Days Exclusive','₹8,50,000','Limited Seats','💎','VIP accommodation, private transport, concierge service, 5-star dining, exclusive Mina camp with all amenities.','hajj-vip')}
        </div>
      </div>
      <div id="tab-ziyarat" class="tab-panel">
        <div class="grid-3" style="margin-top:32px;">
          ${packageCard('Madinah Ziyarat','5 Days City Tour','₹45,000','Add-On','🕌','Visit Masjid An-Nabawi, Quba Mosque, Masjid Al-Qiblatayn, Uhud Mountain and other blessed sites of Madinah.','ziyarat-mad')}
          ${packageCard('Makkah Ziyarat','3 Days Guided','₹30,000','Spiritual','🌟','Comprehensive guided tour of Makkah — Cave Hira, Cave Thawr, Jabal Rahma, Masjid Namira & Arafat plains.','ziyarat-mak')}
          ${packageCard('Combined Ziyarat','8 Days Full Tour','₹70,000','Best Value','🗺','Complete spiritual journey covering all key Ziyarat sites in both Makkah and Madinah with expert scholars.','ziyarat-comb')}
        </div>
      </div>

      <div class="text-center" style="margin-top:48px;">
        <a href="packages.html" class="btn btn-gold">View All Packages ›</a>
      </div>
    </div>
  </section>

  <!-- WHY CHOOSE US -->
  <section class="section-pad islamic-bg">
    <div class="container">
      <div class="grid-2" style="align-items:center;gap:80px;">
        <div class="reveal-left">
          <div class="section-subtitle" style="color:var(--gold);">Why Choose Us</div>
          <h2 class="section-title light">Trusted by Thousands<br>Across India</h2>
          <p class="section-desc light" style="margin:16px 0 40px;">For over two decades, Sana Tour &amp; Travels has been the most trusted name in Hajj and Umrah services — not just as a travel agency, but as a spiritual companion.</p>
          <button class="btn btn-gold" onclick="openPopup('enquiry-popup')">Get Free Consultation 🌙</button>
        </div>
        <div>
          <div class="why-item reveal delay-1" style="background:rgba(255,255,255,0.04);border-color:rgba(201,168,76,0.15);margin-bottom:8px;">
            <div class="why-num" style="color:rgba(201,168,76,0.3);">01</div>
            <div class="why-text"><h4 style="color:var(--cream);">Government Authorized</h4><p style="color:rgba(255,255,255,0.6);">We are an officially authorized Hajj operator with all certifications from the Ministry of Minority Affairs.</p></div>
          </div>
          <div class="why-item reveal delay-2" style="background:rgba(255,255,255,0.04);border-color:rgba(201,168,76,0.15);margin-bottom:8px;">
            <div class="why-num" style="color:rgba(201,168,76,0.3);">02</div>
            <div class="why-text"><h4 style="color:var(--cream);">Scholar-Led Groups</h4><p style="color:rgba(255,255,255,0.6);">Every group is accompanied by qualified Islamic scholars who guide rituals and provide spiritual enrichment.</p></div>
          </div>
          <div class="why-item reveal delay-3" style="background:rgba(255,255,255,0.04);border-color:rgba(201,168,76,0.15);margin-bottom:8px;">
            <div class="why-num" style="color:rgba(201,168,76,0.3);">03</div>
            <div class="why-text"><h4 style="color:var(--cream);">24/7 Dedicated Support</h4><p style="color:rgba(255,255,255,0.6);">Our on-ground team in Saudi Arabia provides round-the-clock support so you can focus on your worship.</p></div>
          </div>
          <div class="why-item reveal delay-4" style="background:rgba(255,255,255,0.04);border-color:rgba(201,168,76,0.15);">
            <div class="why-num" style="color:rgba(201,168,76,0.3);">04</div>
            <div class="why-text"><h4 style="color:var(--cream);">Transparent Pricing</h4><p style="color:rgba(255,255,255,0.6);">No hidden charges. Full cost breakdown upfront with flexible EMI options available for all packages.</p></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- TESTIMONIALS -->
  <section class="section-pad" style="background:var(--cream);">
    <div class="container">
      <div class="text-center reveal">
        <div class="section-subtitle">Testimonials</div>
        <h2 class="section-title">Words from Our Pilgrims</h2>
      </div>
      <div class="grid-3" style="margin-top:56px;">
        ${testimonialCard('Mohammad Riyaz', 'Mumbai', '⭐⭐⭐⭐⭐', 'Alhamdulillah, our Hajj journey with Sana Tours was perfect. The team was available every step of the way. Hotels were excellent and the scholar guiding us made every ritual meaningful.', '🧔')}
        ${testimonialCard('Fatima Begum', 'Hyderabad', '⭐⭐⭐⭐⭐', 'This was my third Umrah with Sana Tours and each time they exceed expectations. The VIP package was absolutely worth it — staying so close to the Haram was a dream come true.', '👩')}
        ${testimonialCard('Abdul Karim', 'Bangalore', '⭐⭐⭐⭐⭐', 'Subhanallah! What a blessed journey. The team handled everything from visa to ziyarat. My parents, who are elderly, were given special care and attention throughout the trip.', '👴')}
      </div>
    </div>
  </section>

  <!-- GALLERY PREVIEW -->
  <section class="section-pad" style="background:var(--white);">
    <div class="container">
      <div class="text-center reveal">
        <div class="section-subtitle">Sacred Moments</div>
        <h2 class="section-title">Glimpses of the Holy Journey</h2>
      </div>
      <div class="gallery-grid reveal" style="margin-top:48px;">
        ${galleryItem('🕋', 'Masjid Al-Haram')}
        ${galleryItem('🌙', 'Night at Kaaba')}
        ${galleryItem('🕌', 'Masjid An-Nabawi')}
        ${galleryItem('🌄', 'Plains of Arafat')}
        ${galleryItem('⛰', 'Jabal Al-Noor')}
      </div>
      <div class="text-center" style="margin-top:40px;">
        <a href="gallery.html" class="btn btn-outline">View Full Gallery ›</a>
      </div>
    </div>
  </section>

  <!-- CTA BANNER -->
  <section class="cta-banner">
    <div class="container text-center reveal">
      <div class="section-subtitle" style="justify-content:center;">Limited Seats Available</div>
      <h2 class="section-title light" style="margin-bottom:24px;">Begin Your Journey<br>to the House of Allah</h2>
      <p class="section-desc light" style="margin:0 auto 40px;">Seats for Hajj 2025 and Umrah are filling up fast. Secure your spot today and embark on the most spiritually enriching journey of your life.</p>
      <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap;">
        <button class="btn btn-gold" onclick="openPopup('booking-popup')">🕋 Book Now</button>
        <button class="btn btn-outline" onclick="openPopup('enquiry-popup')">📞 Get Callback</button>
      </div>
    </div>
  </section>

  ${renderFooter()}`;

  // Welcome popup after 3s
  setTimeout(() => {
    document.getElementById('welcome-popup') && openPopup('welcome-popup');
  }, 3000);
}

// ── Package Card Helper ────────────────────────────────────
function packageCard(name, duration, price, badge, icon, desc, id) {
  return `
  <div class="card reveal">
    <div class="card-img-wrap" style="background:linear-gradient(135deg,var(--green),var(--green-mid));height:200px;display:flex;align-items:center;justify-content:center;position:relative;">
      <div style="font-size:72px;opacity:0.2;position:absolute;">${icon}</div>
      <div style="text-align:center;position:relative;z-index:1;">
        <div style="font-size:48px;">${icon}</div>
        <div style="font-family:var(--font-arabic);color:rgba(255,255,255,0.7);font-size:12px;margin-top:8px;letter-spacing:2px;">SANA TOURS</div>
      </div>
      <div class="pkg-badge">${badge}</div>
      <button class="pkg-wishlist" onclick="showToast('Added to wishlist ❤️')">🤍</button>
    </div>
    <div class="card-body">
      <h3 class="card-title">${name}</h3>
      <div class="pkg-meta">
        <span>📅 ${duration}</span>
        <span>✈️ Includes Flights</span>
      </div>
      <p class="card-text">${desc}</p>
      <div class="pkg-footer">
        <div class="card-price">${price} <span>/ person</span></div>
        <button class="btn btn-gold" style="padding:10px 20px;font-size:12px;" onclick="openPopup('booking-popup')">Book Now</button>
      </div>
    </div>
  </div>`;
}

// ── Testimonial Helper ─────────────────────────────────────
function testimonialCard(name, city, stars, text, emoji) {
  return `
  <div class="testimonial-card reveal">
    <div class="stars">${stars}</div>
    <p class="testimonial-text">${text}</p>
    <div class="testimonial-author">
      <div class="author-avatar">${emoji}</div>
      <div><div class="author-name">${name}</div><div class="author-from">📍 ${city}</div></div>
    </div>
  </div>`;
}

// ── Gallery Item Helper ───────────────────────────────────
function galleryItem(emoji, label) {
  return `
  <div class="gallery-item">
    <div style="width:100%;height:100%;background:linear-gradient(135deg,var(--green),var(--green-mid));display:flex;align-items:center;justify-content:center;flex-direction:column;gap:12px;">
      <div style="font-size:64px;">${emoji}</div>
      <div style="color:rgba(255,255,255,0.5);font-size:12px;letter-spacing:2px;text-transform:uppercase;">${label}</div>
    </div>
    <div class="gallery-overlay"><span>${label}</span></div>
  </div>`;
}

// ──────────────────────────────────────────────────────────
// PACKAGES PAGE
// ──────────────────────────────────────────────────────────
function renderPackages(app) {
  app.innerHTML = `
  ${renderNavbar()}
  ${renderGlobalUI()}

  <section class="page-hero">
    <div class="page-hero-pattern"></div>
    <div class="container">
      <div class="breadcrumb"><a href="index.html">Home</a><span>›</span>Packages</div>
      <div class="section-subtitle">Our Offerings</div>
      <h1 class="section-title light" style="font-size:clamp(40px,6vw,72px);">Hajj &amp; Umrah<br>Packages 2025</h1>
      <p style="color:rgba(255,255,255,0.7);font-size:16px;max-width:500px;margin-top:16px;line-height:1.8;">Tailored spiritual journeys for every pilgrim — from budget-friendly to luxury, all with the same blessed intention.</p>
    </div>
  </section>

  <!-- PACKAGE FILTER -->
  <section class="section-pad" style="background:var(--cream);">
    <div class="container">
      <div class="tab-nav" data-tabs>
        <button class="tab-btn active" data-tab="pkg-all">🕌 All Packages</button>
        <button class="tab-btn" data-tab="pkg-umrah">🌙 Umrah</button>
        <button class="tab-btn" data-tab="pkg-hajj">🕋 Hajj</button>
        <button class="tab-btn" data-tab="pkg-group">👥 Group</button>
        <button class="tab-btn" data-tab="pkg-vip">👑 VIP / Luxury</button>
      </div>

      <div id="pkg-all" class="tab-panel active">
        <div class="grid-3">
          ${packageCard('Economy Umrah','15 Days','₹85,000','Economy','🌙','3-star hotels, group transport, guided ziyarat, visa assistance included.','eco')}
          ${packageCard('Premium Umrah','12 Days','₹1,35,000','Popular','⭐','4-star hotels near Haram, private AC transport, scholar-led group.','prem')}
          ${packageCard('VIP Luxury Umrah','10 Days','₹2,10,000','VIP','👑','5-star Hilton/Marriott, private guide, VIP lounge access.','vip')}
          ${packageCard('Hajj Standard','25 Days','₹3,50,000','Hajj 2025','🕋','Complete guided Hajj with Mina tents, all rituals, full documentation.','hstd')}
          ${packageCard('Hajj Premium','25 Days','₹5,20,000','Best Seller','✨','Premium AC Mina camps, luxury Makkah hotel, exclusive scholar.','hprem')}
          ${packageCard('Group Umrah','15 Days','₹75,000','Group Deal','👥','Special rates for groups of 10+. Economy hotels, full itinerary included.','grp')}
        </div>
      </div>

      <div id="pkg-umrah" class="tab-panel">
        <div class="grid-3">
          ${packageCard('Economy Umrah','15 Days','₹85,000','Economy','🌙','3-star hotels, group transport, guided ziyarat, visa assistance included.','eco2')}
          ${packageCard('Premium Umrah','12 Days','₹1,35,000','Popular','⭐','4-star hotels near Haram, private AC transport, scholar-led group.','prem2')}
          ${packageCard('VIP Luxury Umrah','10 Days','₹2,10,000','VIP','👑','5-star stay, private guide, VIP lounge access, airport chauffeur.','vip2')}
          ${packageCard('Ramadan Umrah','15 Days','₹1,60,000','Special','🌟','Experience the blessing of Umrah in the holy month of Ramadan. Limited seats!','ramadan')}
        </div>
      </div>

      <div id="pkg-hajj" class="tab-panel">
        <div class="grid-3">
          ${packageCard('Hajj Standard','25 Days','₹3,50,000','Hajj 2025','🕋','Complete guided Hajj with Mina tents, all rituals, full documentation.','hstd2')}
          ${packageCard('Hajj Premium','25 Days','₹5,20,000','Best Seller','✨','Premium AC Mina camps, luxury Makkah hotel, exclusive scholar.','hprem2')}
          ${packageCard('Hajj VIP','25 Days','₹8,50,000','Exclusive','💎','5-star throughout, VIP Mina camp, concierge, private transport.','hvip2')}
        </div>
      </div>

      <div id="pkg-group" class="tab-panel">
        <div class="grid-3">
          ${packageCard('Group Umrah (10–20)','15 Days','₹75,000','Group','👥','Special economy rates for groups. Dedicated group coordinator included.','grp2')}
          ${packageCard('Group Umrah (20+)','15 Days','₹65,000','Best Rate','🎯','Bulk booking discount. Ideal for mosques, organizations, and families.','grp3')}
          ${packageCard('Corporate Umrah','12 Days','₹1,20,000','Corporate','🏢','Premium group package for corporate teams. Private flights available.','corp')}
        </div>
      </div>

      <div id="pkg-vip" class="tab-panel">
        <div class="grid-3">
          ${packageCard('VIP Luxury Umrah','10 Days','₹2,10,000','VIP','👑','5-star Hilton/Marriott, private guide, VIP lounge, chauffeur transfers.','vip3')}
          ${packageCard('Hajj VIP','25 Days','₹8,50,000','Exclusive','💎','All 5-star, private AC Mina villa, concierge, scholar, gourmet dining.','hvip3')}
          ${packageCard('Platinum Package','14 Days','₹3,00,000','Platinum','🌟','Ultimate luxury Umrah experience. Suite rooms, private jet option available.','plat')}
        </div>
      </div>
    </div>
  </section>

  <!-- INCLUSIONS -->
  <section class="section-pad islamic-bg">
    <div class="container">
      <div class="text-center reveal">
        <div class="section-subtitle" style="justify-content:center;">What's Included</div>
        <h2 class="section-title light">Every Package Includes</h2>
      </div>
      <div class="grid-4" style="margin-top:56px;">
        ${['✈️ Return Flights','🏨 Hotel Accommodation','🚌 All Transfers','🛂 Visa Processing','📿 Guided Ziyarat','👨‍💼 Scholar Guide','🍽 Meals (Breakfast)','📋 Pre-Departure Training'].map(item => `
        <div class="glass-card text-center reveal" style="text-align:center;">
          <div style="font-size:36px;margin-bottom:12px;">${item.split(' ')[0]}</div>
          <div style="color:var(--cream);font-weight:600;font-size:14px;">${item.substring(3)}</div>
        </div>`).join('')}
      </div>
    </div>
  </section>

  ${renderFooter()}`;
}

// ──────────────────────────────────────────────────────────
// ABOUT PAGE
// ──────────────────────────────────────────────────────────
function renderAbout(app) {
  app.innerHTML = `
  ${renderNavbar()}
  ${renderGlobalUI()}

  <section class="page-hero">
    <div class="page-hero-pattern"></div>
    <div class="container">
      <div class="breadcrumb"><a href="index.html">Home</a><span>›</span>About Us</div>
      <div class="section-subtitle">Our Story</div>
      <h1 class="section-title light" style="font-size:clamp(40px,6vw,72px);">About Sana Tour<br>&amp; Travels</h1>
    </div>
  </section>

  <!-- STORY -->
  <section class="section-pad" style="background:var(--cream);">
    <div class="container">
      <div class="grid-2" style="align-items:center;gap:80px;">
        <div class="reveal-left">
          <div class="section-subtitle">Since 2004</div>
          <h2 class="section-title">Two Decades of<br>Serving the Ummah</h2>
          <p style="color:#555;font-size:15px;line-height:1.9;margin:20px 0;">Founded in 2004, Sana Tour &amp; Travels was born from a simple but powerful vision: to make the sacred journey of Hajj and Umrah accessible, comfortable, and spiritually enriching for every Muslim.</p>
          <p style="color:#555;font-size:15px;line-height:1.9;margin-bottom:32px;">As an Authorized Agent of Atlas Tours &amp; Travels Pvt Ltd, we carry the trust of thousands of pilgrims who have performed their Hajj and Umrah through us. Our commitment is to handle every worldly detail so that you can focus entirely on your worship.</p>
          <div class="grid-2" style="gap:24px;">
            ${['15,000+\nPilgrims Served','20+ Years\nof Experience','100%\nVisa Success','50+\nDestinations'].map(s => {
              const [num, label] = s.split('\n');
              return `<div style="background:var(--white);border-radius:12px;padding:20px;text-align:center;border:2px solid var(--cream-dark);">
                <div style="font-family:var(--font-display);font-size:28px;font-weight:900;color:var(--gold);">${num}</div>
                <div style="font-size:13px;color:#888;margin-top:4px;">${label}</div>
              </div>`;
            }).join('')}
          </div>
        </div>
        <div class="reveal-right">
          <div style="background:linear-gradient(135deg,var(--green),var(--green-mid));border-radius:24px;padding:60px;text-align:center;position:relative;overflow:hidden;">
            <div style="font-size:32px;opacity:0.1;position:absolute;top:20px;right:20px;">☽</div>
            <div style="font-size:80px;margin-bottom:20px;">🕌</div>
            ${getLogo('', 'height:80px;margin-bottom:20px;')}
            <div style="font-family:var(--font-arabic);color:var(--gold);font-size:22px;direction:rtl;margin-bottom:8px;">وَأَتِمُّوا الْحَجَّ وَالْعُمْرَةَ لِلَّهِ</div>
            <div style="color:rgba(255,255,255,0.6);font-size:12px;letter-spacing:1px;">"Complete the Hajj and Umrah for Allah" — Quran 2:196</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- MISSION -->
  <section class="section-pad" style="background:var(--white);">
    <div class="container">
      <div class="text-center reveal">
        <div class="section-subtitle">Our Values</div>
        <h2 class="section-title">Mission, Vision &amp; Values</h2>
      </div>
      <div class="grid-3" style="margin-top:56px;">
        ${[
          {icon:'🎯', title:'Our Mission', desc:'To provide the highest quality Hajj and Umrah services with complete transparency, ensuring every pilgrim has a spiritually fulfilling and physically comfortable journey.'},
          {icon:'🌟', title:'Our Vision', desc:'To become India\'s most trusted and loved Hajj & Umrah service provider, making the sacred journey accessible to every Muslim regardless of their economic background.'},
          {icon:'💚', title:'Our Values', desc:'Faith, Integrity, Service, and Compassion. We treat every pilgrim like family — because in the House of Allah, we are all equal servants of the Most High.'}
        ].map(v => `
        <div class="card reveal text-center" style="padding:40px 32px;">
          <div style="font-size:52px;margin-bottom:20px;">${v.icon}</div>
          <h3 class="card-title">${v.title}</h3>
          <p class="card-text" style="margin-top:8px;">${v.desc}</p>
        </div>`).join('')}
      </div>
    </div>
  </section>

  <!-- TEAM -->
  <section class="section-pad" style="background:var(--cream);">
    <div class="container">
      <div class="text-center reveal">
        <div class="section-subtitle">Our People</div>
        <h2 class="section-title">Meet Our Expert Team</h2>
      </div>
      <div class="grid-4" style="margin-top:56px;">
        ${[
          {emoji:'🧔', name:'Haji Sana Ullah', role:'Founder & CEO'},
          {emoji:'👨‍💼', name:'Mohammad Adil', role:'Operations Director'},
          {emoji:'🧕', name:'Fatima Siddiqui', role:'Hajj Coordinator'},
          {emoji:'👨‍🏫', name:'Maulana Rashid', role:'Chief Alim & Guide'},
        ].map(m => `
        <div class="team-card reveal">
          <div class="team-avatar">${m.emoji}</div>
          <div class="team-name">${m.name}</div>
          <div class="team-role" style="margin-top:6px;">${m.role}</div>
        </div>`).join('')}
      </div>
    </div>
  </section>

  <!-- CERTIFICATIONS -->
  <section class="section-pad islamic-bg">
    <div class="container text-center">
      <div class="section-subtitle" style="justify-content:center;">Trust &amp; Certifications</div>
      <h2 class="section-title light reveal">Our Accreditations</h2>
      <div class="grid-4" style="margin-top:56px;">
        ${['🏛 Ministry of Minority Affairs','📜 IATA Certified Agent','✅ Atlas Tours Authorized','🌍 Saudi MOH Registered'].map(c => `
        <div class="glass-card reveal text-center">
          <div style="font-size:32px;margin-bottom:12px;">${c.split(' ')[0]}</div>
          <div style="color:var(--cream);font-size:14px;font-weight:600;">${c.substring(3)}</div>
        </div>`).join('')}
      </div>
    </div>
  </section>

  ${renderFooter()}`;
}

// ──────────────────────────────────────────────────────────
// GALLERY PAGE
// ──────────────────────────────────────────────────────────
function renderGallery(app) {
  const photos = [
    {e:'🕋',l:'Masjid Al-Haram, Makkah'},{e:'🌙',l:'Night of Kaaba Tawaf'},
    {e:'🕌',l:'Masjid An-Nabawi'},{e:'🌄',l:'Plains of Arafat'},
    {e:'⛰',l:'Jabal Al-Noor - Cave Hira'},{e:'🌟',l:'Jabal Thawr'},
    {e:'🏔',l:'Muzdalifah Night'},{e:'🌅',l:'Sunrise at Mina'},
    {e:'📿',l:'Pilgrims in Ihram'},{e:'💚',l:'Masjid Quba'},
    {e:'🌊',l:'Zamzam Well'},{e:'🦅',l:'Jabal Rahma - Arafat'},
  ];

  app.innerHTML = `
  ${renderNavbar()}
  ${renderGlobalUI()}

  <section class="page-hero">
    <div class="page-hero-pattern"></div>
    <div class="container">
      <div class="breadcrumb"><a href="index.html">Home</a><span>›</span>Gallery</div>
      <div class="section-subtitle">Sacred Moments</div>
      <h1 class="section-title light">Gallery of Holy Journeys</h1>
    </div>
  </section>

  <section class="section-pad" style="background:var(--cream);">
    <div class="container">
      <div class="tab-nav" data-tabs>
        <button class="tab-btn active" data-tab="gal-all">All</button>
        <button class="tab-btn" data-tab="gal-makkah">🕋 Makkah</button>
        <button class="tab-btn" data-tab="gal-madinah">🕌 Madinah</button>
        <button class="tab-btn" data-tab="gal-pilgrims">📿 Pilgrims</button>
      </div>

      <div id="gal-all" class="tab-panel active">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;">
          ${photos.map((p,i) => `
          <div class="gallery-item reveal" style="height:250px;border-radius:16px;cursor:pointer;" onclick="openLightbox('${p.l}','${p.e}')">
            <div style="width:100%;height:100%;background:linear-gradient(135deg,var(--green),var(--green-mid));display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;transition:transform 0.3s;" >
              <div style="font-size:64px;">${p.e}</div>
              <div style="color:rgba(255,255,255,0.5);font-size:11px;letter-spacing:2px;text-transform:uppercase;">${p.l}</div>
            </div>
            <div class="gallery-overlay"><span>🔍 ${p.l}</span></div>
          </div>`).join('')}
        </div>
      </div>
      <div id="gal-makkah" class="tab-panel">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;">
          ${photos.slice(0,6).map(p => `
          <div class="gallery-item reveal" style="height:250px;border-radius:16px;" onclick="openLightbox('${p.l}','${p.e}')">
            <div style="width:100%;height:100%;background:linear-gradient(135deg,var(--green),var(--green-mid));display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;">
              <div style="font-size:64px;">${p.e}</div>
              <div style="color:rgba(255,255,255,0.5);font-size:11px;letter-spacing:2px;text-transform:uppercase;">${p.l}</div>
            </div>
            <div class="gallery-overlay"><span>${p.l}</span></div>
          </div>`).join('')}
        </div>
      </div>
      <div id="gal-madinah" class="tab-panel">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;">
          ${photos.slice(2,5).map(p => `
          <div class="gallery-item reveal" style="height:250px;border-radius:16px;" onclick="openLightbox('${p.l}','${p.e}')">
            <div style="width:100%;height:100%;background:linear-gradient(135deg,var(--green),var(--green-mid));display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;">
              <div style="font-size:64px;">${p.e}</div>
              <div style="color:rgba(255,255,255,0.5);font-size:11px;letter-spacing:2px;text-transform:uppercase;">${p.l}</div>
            </div>
            <div class="gallery-overlay"><span>${p.l}</span></div>
          </div>`).join('')}
        </div>
      </div>
      <div id="gal-pilgrims" class="tab-panel">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;">
          ${photos.slice(8,12).map(p => `
          <div class="gallery-item reveal" style="height:250px;border-radius:16px;" onclick="openLightbox('${p.l}','${p.e}')">
            <div style="width:100%;height:100%;background:linear-gradient(135deg,var(--green),var(--green-mid));display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;">
              <div style="font-size:64px;">${p.e}</div>
              <div style="color:rgba(255,255,255,0.5);font-size:11px;letter-spacing:2px;text-transform:uppercase;">${p.l}</div>
            </div>
            <div class="gallery-overlay"><span>${p.l}</span></div>
          </div>`).join('')}
        </div>
      </div>
    </div>
  </section>

  <!-- Lightbox Popup -->
  <div class="popup-overlay" id="lightbox-popup">
    <div class="popup-box" style="max-width:500px;background:var(--green);">
      <button class="popup-close" onclick="closePopup('lightbox-popup')">✕</button>
      <div id="lightbox-content" style="padding:60px;text-align:center;"></div>
    </div>
  </div>

  ${renderFooter()}`;
}

window.openLightbox = function(label, emoji) {
  const c = document.getElementById('lightbox-content');
  if (c) {
    c.innerHTML = `
      <div style="font-size:96px;margin-bottom:20px;">${emoji}</div>
      <div style="font-family:var(--font-display);font-size:22px;color:var(--cream);font-weight:700;">${label}</div>
      <div style="color:var(--gold);font-size:13px;margin-top:8px;letter-spacing:2px;">Blessed Moments</div>`;
  }
  openPopup('lightbox-popup');
};

// ──────────────────────────────────────────────────────────
// FAQ PAGE
// ──────────────────────────────────────────────────────────
function renderFaq(app) {
  const faqs = [
    {q:'What is included in the Umrah package?', a:'Our Umrah packages include return airfare, hotel accommodation in Makkah and Madinah, all internal transfers between cities, visa processing, guided Ziyarat tours, and a dedicated scholar for religious guidance throughout the journey.'},
    {q:'How do I apply for a Hajj or Umrah visa?', a:'We handle the entire visa process on your behalf. You need to provide a valid passport (min 6 months validity), passport-size photos, vaccination records, and relevant personal documents. Our team will guide you through every step.'},
    {q:'What is the minimum age for Umrah?', a:'There is no minimum age for Umrah. However, children under 18 must be accompanied by a parent or legal guardian. For Hajj, very young children are generally discouraged due to the physically demanding nature of the pilgrimage.'},
    {q:'Are flights included in all packages?', a:'Yes, return flights are included in all our standard, premium, and VIP packages. Group packages may have flight options as an add-on. Please confirm with our team at the time of booking.'},
    {q:'What hotels are used for accommodation?', a:'We partner with top-rated hotels close to the Haram. Economy packages use 3-star hotels within 500m of the mosque. Premium packages use 4-star hotels within 200m. VIP packages include 5-star options like Hilton, Marriott, and Makkah Clock Tower.'},
    {q:'Is there a scholar who guides the rituals?', a:'Absolutely. Every group is accompanied by a qualified Islamic scholar who has performed Hajj/Umrah multiple times. They conduct daily sessions, guide all rituals, answer religious questions, and provide daily Islamic reminders throughout the journey.'},
    {q:'Can I customize my package?', a:'Yes! We offer highly flexible packages. You can add extra nights, upgrade hotels, include additional Ziyarat tours, or arrange private transport. Contact our team to create a fully personalized pilgrimage experience.'},
    {q:'Are there EMI payment options?', a:'Yes, we offer 0% interest EMI plans for eligible customers. You can pay in installments over 3, 6, or 12 months. A booking deposit of 20% secures your seat. Contact us for details and eligibility.'},
    {q:'What documentation is required for Hajj?', a:'For Hajj, you need a valid passport, Hajj visa application, meningitis vaccination certificate, COVID-19 documentation (as required), marriage certificate (for women traveling with spouse), and mahram documentation for women.'},
    {q:'Is food included in the packages?', a:'Most packages include breakfast daily. Premium and VIP packages include breakfast and dinner. Lunch is generally not included as pilgrims often eat near the mosque. Halal food is available throughout Makkah and Madinah.'},
  ];

  app.innerHTML = `
  ${renderNavbar()}
  ${renderGlobalUI()}

  <section class="page-hero">
    <div class="page-hero-pattern"></div>
    <div class="container">
      <div class="breadcrumb"><a href="index.html">Home</a><span>›</span>FAQ</div>
      <div class="section-subtitle">Your Questions Answered</div>
      <h1 class="section-title light">Frequently Asked<br>Questions</h1>
    </div>
  </section>

  <section class="section-pad" style="background:var(--cream);">
    <div class="container">
      <div class="grid-2" style="gap:60px;align-items:start;">
        <div>
          <div class="section-subtitle">Common Questions</div>
          <h2 class="section-title" style="margin-bottom:32px;">Everything You<br>Need to Know</h2>
          ${faqs.map(f => `
          <div class="accordion-item reveal">
            <div class="accordion-header">
              <span>${f.q}</span>
              <div class="accordion-icon">+</div>
            </div>
            <div class="accordion-body">${f.a}</div>
          </div>`).join('')}
        </div>
        <div style="position:sticky;top:100px;">
          <div class="card" style="padding:40px;text-align:center;">
            <div style="font-size:48px;margin-bottom:16px;">💬</div>
            <h3 class="card-title">Still have questions?</h3>
            <p class="card-text" style="margin:12px 0 24px;">Our experts are available 6 days a week to answer all your questions and help plan your journey.</p>
            <button class="btn btn-gold" style="width:100%;justify-content:center;margin-bottom:12px;" onclick="openPopup('enquiry-popup')">📞 Call Us Now</button>
            <button class="btn btn-outline" style="width:100%;justify-content:center;" onclick="window.open('https://wa.me/919876543210','_blank')">💬 WhatsApp Us</button>
            <div style="margin-top:24px;padding-top:24px;border-top:1px solid var(--cream-dark);">
              <div style="font-weight:700;color:var(--green);margin-bottom:8px;">Office Hours</div>
              <div style="font-size:14px;color:#888;">Mon–Sat: 9:00 AM – 7:00 PM<br>Friday: Closed 12:00 – 2:00 PM</div>
            </div>
          </div>
          <div class="card reveal" style="padding:32px;margin-top:20px;background:linear-gradient(135deg,var(--green),var(--green-mid));color:var(--cream);">
            <div style="font-family:var(--font-arabic);font-size:20px;direction:rtl;color:var(--gold);margin-bottom:8px;">اللَّهُمَّ اجْعَلْهُ حَجًّا مَبْرُوراً</div>
            <div style="font-size:13px;color:rgba(255,255,255,0.7);">"O Allah, make it a blessed Hajj"</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  ${renderFooter()}`;
}

// ──────────────────────────────────────────────────────────
// CONTACT PAGE
// ──────────────────────────────────────────────────────────
function renderContact(app) {
  app.innerHTML = `
  ${renderNavbar()}
  ${renderGlobalUI()}

  <section class="page-hero">
    <div class="page-hero-pattern"></div>
    <div class="container">
      <div class="breadcrumb"><a href="index.html">Home</a><span>›</span>Contact</div>
      <div class="section-subtitle">Get In Touch</div>
      <h1 class="section-title light">Contact Sana Tour<br>&amp; Travels</h1>
    </div>
  </section>

  <section class="section-pad" style="background:var(--cream);">
    <div class="container">
      <div class="grid-2" style="gap:60px;align-items:start;">
        <div class="reveal-left">
          <div class="contact-info-card">
            <div style="font-family:var(--font-display);font-size:24px;font-weight:700;color:var(--cream);margin-bottom:8px;">We'd Love to Hear<br>From You</div>
            <p style="color:rgba(255,255,255,0.6);font-size:14px;line-height:1.8;margin-bottom:32px;">Whether you have questions about packages, visa requirements, or want to book your journey — our team is here to help.</p>
            <div class="contact-info-item">
              <div class="contact-icon-box">📍</div>
              <div><div style="color:var(--gold);font-weight:600;margin-bottom:4px;">Office Address</div><div style="font-size:14px;color:rgba(255,255,255,0.7);">123 Masjid Road, Muslim Colony,<br>Mumbai – 400001, Maharashtra, India</div></div>
            </div>
            <div class="contact-info-item">
              <div class="contact-icon-box">📞</div>
              <div><div style="color:var(--gold);font-weight:600;margin-bottom:4px;">Phone Numbers</div><div style="font-size:14px;color:rgba(255,255,255,0.7);">+91 98765 43210<br>+91 87654 32109</div></div>
            </div>
            <div class="contact-info-item">
              <div class="contact-icon-box">✉️</div>
              <div><div style="color:var(--gold);font-weight:600;margin-bottom:4px;">Email</div><div style="font-size:14px;color:rgba(255,255,255,0.7);">info@sanatours.com<br>hajj@sanatours.com</div></div>
            </div>
            <div class="contact-info-item">
              <div class="contact-icon-box">🕌</div>
              <div><div style="color:var(--gold);font-weight:600;margin-bottom:4px;">Office Hours</div><div style="font-size:14px;color:rgba(255,255,255,0.7);">Monday to Saturday: 9:00 AM – 7:00 PM<br>Friday: Closed 12:00 PM – 2:00 PM (Jumu'ah)</div></div>
            </div>
            <div style="margin-top:32px;padding-top:32px;border-top:1px solid rgba(255,255,255,0.1);">
              <div style="font-family:var(--font-arabic);font-size:20px;color:var(--gold);direction:rtl;text-align:center;">رَبَّنَا تَقَبَّلْ مِنَّا</div>
              <div style="text-align:center;font-size:12px;color:rgba(255,255,255,0.4);margin-top:4px;">"Our Lord, accept from us"</div>
            </div>
          </div>
        </div>
        <div class="reveal-right">
          <div class="card" style="padding:40px;">
            <h3 class="card-title" style="margin-bottom:28px;">Send Us a Message</h3>
            <form>
              <div class="form-row">
                <div class="form-group">
                  <label class="form-label">First Name</label>
                  <input class="form-control" type="text" placeholder="Mohammad" required>
                </div>
                <div class="form-group">
                  <label class="form-label">Last Name</label>
                  <input class="form-control" type="text" placeholder="Ahmed" required>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Phone Number</label>
                <input class="form-control" type="tel" placeholder="+91 98765 43210" required>
              </div>
              <div class="form-group">
                <label class="form-label">Email Address</label>
                <input class="form-control" type="email" placeholder="your@email.com">
              </div>
              <div class="form-group">
                <label class="form-label">Subject</label>
                <select class="form-control">
                  <option>Enquiry about Hajj Package</option>
                  <option>Enquiry about Umrah Package</option>
                  <option>Visa Assistance</option>
                  <option>Group Booking</option>
                  <option>General Inquiry</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Your Message</label>
                <textarea class="form-control" rows="5" placeholder="Tell us about your travel plans, number of pilgrims, preferred dates..." required></textarea>
              </div>
              <button type="submit" class="btn btn-gold" style="width:100%;justify-content:center;font-size:15px;">
                🌙 Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- MAP PLACEHOLDER -->
  <section style="height:350px;background:linear-gradient(135deg,var(--green),var(--green-mid));display:flex;align-items:center;justify-content:center;flex-direction:column;gap:16px;">
    <div style="font-size:48px;">📍</div>
    <div style="font-family:var(--font-display);font-size:24px;color:var(--cream);font-weight:700;">123 Masjid Road, Mumbai</div>
    <div style="color:rgba(255,255,255,0.6);font-size:14px;">Click to open in Google Maps</div>
    <a href="https://maps.google.com" target="_blank" class="btn btn-gold" style="margin-top:8px;">Open in Maps ›</a>
  </section>

  ${renderFooter()}`;
}
